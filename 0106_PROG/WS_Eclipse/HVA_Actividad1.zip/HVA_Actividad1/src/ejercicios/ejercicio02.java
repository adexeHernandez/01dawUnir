package ejercicios;

public class ejercicio02 {

	public static void main(String[] args) {
		/*
		 *  Diseñar un programa que muestre el producto y la suma de los 10 primeros
		 *  números impares.
		 */

		int suma = 0;
		int producto = 1;

		for (int i = 0; i < 20; i++) {
			if (i % 2 != 0) {
				suma += i;
				producto *= i;
			}
		}
		System.out.println("La suma de los 10 primeros números impares es : " + suma);
		System.out.println("El producto de los 10 primeros números impares es : " + producto);
	}
}