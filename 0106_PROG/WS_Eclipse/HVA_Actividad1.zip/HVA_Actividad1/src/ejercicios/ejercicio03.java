package ejercicios;

public class ejercicio03 {

	public static void main(String[] args) {
		/*
		 * Escribir todos los números del 100 al 0 de 7 en 7. Al final mostrar las
		 * siguientes Estadísticas. Cuantos números has escrito, Cuanto suman los
		 * números escritos, Cuantos de estos números son pares.
		 */
		
		int num = 100, contNum = 0, suma = 0, contPares = 0;
		
		while (num >= 0) {
			contNum++;
			suma += num;
			if (num % 2 == 0) {
				contPares++;
			}
			num -= 7;
		}
		
		System.out.println("Has escrito " + contNum + " números");
		System.out.println("La suma total de los números escritos es: " + suma);
		System.out.println("De los números escritos " + contPares + " son pares");
		System.out.println("FIN DE PROGRAMA");
	}

}
