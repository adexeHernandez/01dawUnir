package ejercicios;

import java.util.Scanner;

public class ejercicio04 {

	public static void main(String[] args) {
		/*
		 * Leer números hasta que se introduzca un cero. Para cada uno indicar si es par
		 * o impar. Al final mostrar las siguientes Estadísticas: cuantos son pares e
		 * impares, cuanto suman los pares y cuanto los impares.
		 */

		Scanner leer = new Scanner(System.in);

		int num = 1, contPares = 0, contImpares = 0, sumPares = 0, sumImpares = 0;

		while (num != 0) {

			System.out.println("Dame numeros enteros. Escribe 0 para terminar");
			num = leer.nextInt();

			if (num != 0) {
				if (num % 2 == 0) {
					contPares++;
					sumPares += num;
				} else {
					contImpares++;
					sumImpares += num;
				}

			}
		}

		System.out.println("Estadísticas : ");
		System.out.println("Total de números pares : " + contPares);
		System.out.println("Total de números impares : " + contImpares);
		System.out.println("La suma total de los números pares es : " + sumPares);
		System.out.println("La suma total de los números impares es : " + sumImpares);
		System.out.println("FIN DE PROGRAMA");

		leer.close();

	}

}
